STUDENT ATTENDANCE MANAGEMENT SYSTEM
=====================================

Technology:
- Python 3
- Tkinter (GUI)
- CSV file handling

FEATURES
--------
1. Add student attendance records.
2. Enter student name, roll number, subject, total classes and attended classes.
3. Automatically calculate attendance percentage.
4. Show status using a 75% threshold.
5. View all records in a table.
6. Delete selected records.
7. Save records automatically in attendance_records.csv.
8. Show dashboard summary: total records, satisfactory and shortage.

HOW TO RUN IN VS CODE
---------------------
1. Extract the ZIP folder.
2. Open the extracted folder in VS Code (File > Open Folder).
3. Open attendance_management.py.
4. Make sure Python 3 is installed.
5. Click the Run button, or open Terminal and type:
   python attendance_management.py

If your system uses the py command, try:
   py attendance_management.py

No extra Python package is required. Tkinter and CSV are included with most standard Python installations.

IMPORTANT
---------
The CSV file is created automatically in the same working folder when the first record is added.
The project uses sample/manual entries; it is not connected to a college database.
The 75% threshold is a configurable rule used for this demonstration.
