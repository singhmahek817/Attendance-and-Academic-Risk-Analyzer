import tkinter as tk
from tkinter import ttk, messagebox
import csv
import os

# Student Attendance Management System
# Developed using Python Tkinter and CSV file handling

DATA_FILE = "attendance_records.csv"

class AttendanceApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Student Attendance Management System")
        self.root.geometry("1050x680")
        self.root.minsize(900, 600)
        self.root.configure(bg="#f3f6fb")

        self.style = ttk.Style()
        self.style.theme_use("clam")
        self.style.configure(
            "Treeview", background="white", foreground="#243247",
            rowheight=30, fieldbackground="white", font=("Arial", 10)
        )
        self.style.configure(
            "Treeview.Heading", background="#e8eef7",
            foreground="#243247", font=("Arial", 10, "bold")
        )
        self.style.map("Treeview", background=[("selected", "#cfe2ff")])

        self.build_header()
        self.build_form()
        self.build_summary()
        self.build_table()
        self.load_records()
        self.refresh_summary()

    def build_header(self):
        header = tk.Frame(self.root, bg="#173b67", height=92)
        header.pack(fill="x")
        header.pack_propagate(False)

        tk.Label(
            header, text="STUDENT ATTENDANCE MANAGEMENT SYSTEM",
            bg="#173b67", fg="white", font=("Arial", 19, "bold")
        ).pack(anchor="w", padx=25, pady=(19, 2))
        tk.Label(
            header, text="Record, monitor and manage student attendance",
            bg="#173b67", fg="#dce9f8", font=("Arial", 10)
        ).pack(anchor="w", padx=27)

    def build_form(self):
        card = tk.LabelFrame(
            self.root, text="  Add Attendance Record  ",
            bg="white", fg="#173b67", font=("Arial", 11, "bold"),
            padx=15, pady=12, bd=1, relief="solid"
        )
        card.pack(fill="x", padx=22, pady=(18, 12))

        fields = [
            ("Student Name", "name"),
            ("Roll Number", "roll"),
            ("Subject", "subject"),
            ("Total Classes", "total"),
            ("Attended Classes", "attended")
        ]
        self.entries = {}
        for col, (label, key) in enumerate(fields):
            tk.Label(card, text=label, bg="white", fg="#43536a",
                     font=("Arial", 9, "bold")).grid(row=0, column=col, sticky="w", padx=7)
            entry = tk.Entry(card, font=("Arial", 10), width=17,
                             relief="solid", bd=1)
            entry.grid(row=1, column=col, padx=7, pady=(5, 10), ipady=6, sticky="ew")
            self.entries[key] = entry

        for col in range(5):
            card.grid_columnconfigure(col, weight=1)

        buttons = tk.Frame(card, bg="white")
        buttons.grid(row=2, column=0, columnspan=5, sticky="w", padx=5)
        tk.Button(
            buttons, text="Add Record", command=self.add_record,
            bg="#1769aa", fg="white", activebackground="#12558b",
            activeforeground="white", relief="flat", padx=18, pady=8,
            font=("Arial", 10, "bold"), cursor="hand2"
        ).pack(side="left", padx=(0, 8))
        tk.Button(
            buttons, text="Clear Fields", command=self.clear_fields,
            bg="#e8eef7", fg="#243247", activebackground="#d7e2f0",
            relief="flat", padx=18, pady=8, font=("Arial", 10),
            cursor="hand2"
        ).pack(side="left")

    def build_summary(self):
        area = tk.Frame(self.root, bg="#f3f6fb")
        area.pack(fill="x", padx=22, pady=4)
        self.summary_labels = {}
        items = [
            ("records", "TOTAL RECORDS", "0"),
            ("safe", "SATISFACTORY", "0"),
            ("short", "ATTENDANCE SHORTAGE", "0")
        ]
        for key, title, value in items:
            box = tk.Frame(area, bg="white", highlightbackground="#dce4ef",
                           highlightthickness=1, padx=15, pady=10)
            box.pack(side="left", fill="x", expand=True, padx=(0, 10))
            tk.Label(box, text=title, bg="white", fg="#66758a",
                     font=("Arial", 9, "bold")).pack(anchor="w")
            number = tk.Label(box, text=value, bg="white", fg="#173b67",
                              font=("Arial", 21, "bold"))
            number.pack(anchor="w", pady=(3, 0))
            self.summary_labels[key] = number

    def build_table(self):
        section = tk.Frame(self.root, bg="white", padx=12, pady=12,
                           highlightbackground="#dce4ef", highlightthickness=1)
        section.pack(fill="both", expand=True, padx=22, pady=(12, 20))

        top = tk.Frame(section, bg="white")
        top.pack(fill="x", pady=(0, 10))
        tk.Label(top, text="Attendance Records", bg="white", fg="#173b67",
                 font=("Arial", 12, "bold")).pack(side="left")
        tk.Button(
            top, text="Delete Selected", command=self.delete_record,
            bg="#b83b45", fg="white", activebackground="#9f3039",
            activeforeground="white", relief="flat", padx=12, pady=6,
            font=("Arial", 9, "bold"), cursor="hand2"
        ).pack(side="right")

        columns = ("name", "roll", "subject", "total", "attended", "percentage", "status")
        self.table = ttk.Treeview(section, columns=columns, show="headings")
        headings = {
            "name": "Student Name", "roll": "Roll Number", "subject": "Subject",
            "total": "Total Classes", "attended": "Attended",
            "percentage": "Attendance %", "status": "Status"
        }
        widths = {"name": 155, "roll": 115, "subject": 130, "total": 100,
                  "attended": 95, "percentage": 115, "status": 165}
        for col in columns:
            self.table.heading(col, text=headings[col])
            self.table.column(col, width=widths[col], anchor="center")
        self.table.column("name", anchor="w")
        self.table.pack(fill="both", expand=True)

        self.table.tag_configure("shortage", foreground="#b3261e")
        self.table.tag_configure("satisfactory", foreground="#18794e")

        tk.Label(
            section, text="Note: 75% is the minimum attendance requirement used by this project.",
            bg="white", fg="#77859a", font=("Arial", 9)
        ).pack(anchor="w", pady=(9, 0))

    def add_record(self):
        name = self.entries["name"].get().strip()
        roll = self.entries["roll"].get().strip()
        subject = self.entries["subject"].get().strip()
        total_text = self.entries["total"].get().strip()
        attended_text = self.entries["attended"].get().strip()

        if not all([name, roll, subject, total_text, attended_text]):
            messagebox.showwarning("Missing Information", "Please fill in all fields.")
            return

        try:
            total = int(total_text)
            attended = int(attended_text)
        except ValueError:
            messagebox.showerror("Invalid Input", "Total and attended classes must be whole numbers.")
            return

        if total <= 0:
            messagebox.showerror("Invalid Input", "Total classes must be greater than zero.")
            return
        if attended < 0 or attended > total:
            messagebox.showerror("Invalid Input", "Attended classes must be between 0 and total classes.")
            return

        percentage = (attended / total) * 100
        status = "Attendance Shortage" if percentage < 75 else "Satisfactory"
        record = [name, roll, subject, total, attended, f"{percentage:.2f}", status]

        file_exists = os.path.exists(DATA_FILE)
        with open(DATA_FILE, "a", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            if not file_exists or os.path.getsize(DATA_FILE) == 0:
                writer.writerow(["name", "roll", "subject", "total", "attended", "percentage", "status"])
            writer.writerow(record)

        self.table.insert("", "end", values=record,
                          tags=("shortage" if percentage < 75 else "satisfactory",))
        self.clear_fields()
        self.refresh_summary()
        messagebox.showinfo("Record Added", f"Attendance saved successfully.\nPercentage: {percentage:.2f}%\nStatus: {status}")

    def load_records(self):
        if not os.path.exists(DATA_FILE):
            return
        try:
            with open(DATA_FILE, "r", newline="", encoding="utf-8") as file:
                reader = csv.DictReader(file)
                for row in reader:
                    values = (
                        row["name"], row["roll"], row["subject"], row["total"],
                        row["attended"], row["percentage"], row["status"]
                    )
                    tag = "shortage" if float(row["percentage"]) < 75 else "satisfactory"
                    self.table.insert("", "end", values=values, tags=(tag,))
        except (KeyError, ValueError):
            messagebox.showerror("File Error", "The attendance CSV file has an unexpected format.")

    def delete_record(self):
        selected = self.table.selection()
        if not selected:
            messagebox.showwarning("No Selection", "Please select a record to delete.")
            return
        if not messagebox.askyesno("Confirm Delete", "Delete the selected record(s)?"):
            return

        for item in selected:
            self.table.delete(item)
        self.save_all_records()
        self.refresh_summary()

    def save_all_records(self):
        with open(DATA_FILE, "w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerow(["name", "roll", "subject", "total", "attended", "percentage", "status"])
            for item in self.table.get_children():
                writer.writerow(self.table.item(item, "values"))

    def clear_fields(self):
        for entry in self.entries.values():
            entry.delete(0, tk.END)

    def refresh_summary(self):
        records = [self.table.item(item, "values") for item in self.table.get_children()]
        total = len(records)
        satisfactory = sum(1 for row in records if float(row[5]) >= 75)
        shortage = total - satisfactory
        self.summary_labels["records"].config(text=str(total))
        self.summary_labels["safe"].config(text=str(satisfactory))
        self.summary_labels["short"].config(text=str(shortage))


if __name__ == "__main__":
    root = tk.Tk()
    app = AttendanceApp(root)
    root.mainloop()
