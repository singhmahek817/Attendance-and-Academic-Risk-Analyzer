def calculate_attendance():
    total = int(input("Enter total classes conducted: "))
    attended = int(input("Enter classes attended: "))
    if total <= 0:
        print("Total classes must be greater than 0.")
        return
    if attended < 0 or attended > total:
        print("Invalid attendance data.")
        return
    percentage = (attended / total) * 100
    print(f"Attendance Percentage: {percentage:.2f}%")
    if percentage < 75:
        print("Status: Attendance Shortage")
    else:
        print("Status: Attendance Satisfactory")


calculate_attendance()